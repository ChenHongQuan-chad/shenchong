wp.i18n.setLocaleData( { '': {} }, 'essgrid' );
